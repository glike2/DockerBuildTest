apt update -y 
apt install -y git tree 
