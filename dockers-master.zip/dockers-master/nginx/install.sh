apt update -y
apt install -y nginx
